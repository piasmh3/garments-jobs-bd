import 'package:flutter/material.dart';
import 'data/jobs.dart';
import 'models/job.dart';
import 'widgets/job_card.dart';

void main() => runApp(const GarmentsJobsApp());

class GarmentsJobsApp extends StatelessWidget {
  const GarmentsJobsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Garments Jobs BD',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1457D9)), scaffoldBackgroundColor: const Color(0xFFF7F9FC), fontFamily: 'Roboto'),
    home: const Shell(),
  );
}

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState()=>_ShellState(); }
class _ShellState extends State<Shell> {
  int index=0; final Set<String> saved={};
  final pages=['হোম','সার্চ','সেভড','প্রোফাইল'];
  @override Widget build(BuildContext context) {
    final page = switch(index){0=>Home(saved:saved,onSave:_toggle,onOpen:_open),1=>SearchPage(saved:saved,onSave:_toggle,onOpen:_open),2=>SavedPage(saved:saved,onSave:_toggle,onOpen:_open),_=>ProfilePage()};
    return Scaffold(body: SafeArea(child: page), bottomNavigationBar: NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v), destinations: const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'হোম'),NavigationDestination(icon:Icon(Icons.search),label:'সার্চ'),NavigationDestination(icon:Icon(Icons.bookmark_border),selectedIcon:Icon(Icons.bookmark),label:'সেভড'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'প্রোফাইল')]));
  }
  void _toggle(Job j){setState((){saved.contains(j.id)?saved.remove(j.id):saved.add(j.id);});}
  void _open(Job j)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>JobDetails(job:j,saved:saved.contains(j.id),onSave:()=>_toggle(j))));
}

class Home extends StatelessWidget { final Set<String> saved; final void Function(Job) onSave; final void Function(Job) onOpen; const Home({super.key,required this.saved,required this.onSave,required this.onOpen});
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.fromLTRB(18,18,18,28),children:[
    Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('আসসালামু আলাইকুম 👋',style:TextStyle(color:Colors.grey.shade700)),const SizedBox(height:4),const Text('আপনার পরের চাকরি খুঁজুন',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900))]),),IconButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const Notifications())),icon:const Icon(Icons.notifications_none))]),
    const SizedBox(height:18), TextField(decoration:InputDecoration(hintText:'চাকরি, পদ বা কোম্পানি খুঁজুন',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none))),
    const SizedBox(height:18), Row(children:[_cat(Icons.factory_outlined,'গার্মেন্টস'),_cat(Icons.location_on_outlined,'লোকেশন'),_cat(Icons.tune,'ফিল্টার')]),
    const SizedBox(height:24), _section('Featured Jobs'), ...jobs.where((j)=>j.featured).map((j)=>JobCard(job:j,saved:saved.contains(j.id),onTap:()=>onOpen(j),onSave:()=>onSave(j))),
    const SizedBox(height:8), _section('সর্বশেষ চাকরি'), ...jobs.map((j)=>JobCard(job:j,saved:saved.contains(j.id),onTap:()=>onOpen(j),onSave:()=>onSave(j))),
  ]);
  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(bottom:12),child:Text(s,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900)));
  Widget _cat(IconData i,String t)=>Expanded(child:Container(margin:const EdgeInsets.only(right:8),padding:const EdgeInsets.symmetric(vertical:13),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(14)),child:Column(children:[Icon(i,color:const Color(0xFF1457D9)),const SizedBox(height:4),Text(t,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600))])));
}

class SearchPage extends StatefulWidget { final Set<String> saved; final void Function(Job) onSave; final void Function(Job) onOpen; const SearchPage({super.key,required this.saved,required this.onSave,required this.onOpen}); @override State<SearchPage> createState()=>_SearchState(); }
class _SearchState extends State<SearchPage>{String q='';String loc='সব এলাকা';@override Widget build(BuildContext c){final list=jobs.where((j)=>(q.isEmpty||'${j.title} ${j.company}'.toLowerCase().contains(q.toLowerCase()))&&(loc=='সব এলাকা'||j.location.contains(loc))).toList();return Column(children:[Padding(padding:const EdgeInsets.fromLTRB(18,18,18,8),child:TextField(autofocus:false,onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(hintText:'Search jobs...',prefixIcon:const Icon(Icons.search),suffixIcon:PopupMenuButton<String>(onSelected:(v)=>setState(()=>loc=v),itemBuilder:(_)=>['সব এলাকা','গাজীপুর','ঢাকা','সাভার','নারায়ণগঞ্জ'].map((e)=>PopupMenuItem(value:e,child:Text(e))).toList(),icon:const Icon(Icons.tune)),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none)))),Expanded(child:ListView(padding:const EdgeInsets.all(18),children:[Text('${list.length}টি চাকরি পাওয়া গেছে',style:const TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:12),...list.map((j)=>JobCard(job:j,saved:widget.saved.contains(j.id),onTap:()=>widget.onOpen(j),onSave:()=>widget.onSave(j)))]) )]);}}

class SavedPage extends StatelessWidget {final Set<String> saved;final void Function(Job) onSave;final void Function(Job) onOpen;const SavedPage({super.key,required this.saved,required this.onSave,required this.onOpen});@override Widget build(BuildContext c){final list=jobs.where((j)=>saved.contains(j.id)).toList();return ListView(padding:const EdgeInsets.all(18),children:[const Text('Saved Jobs',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:18),if(list.isEmpty)const Center(child:Padding(padding:EdgeInsets.all(40),child:Text('এখনও কোনো চাকরি Save করা হয়নি।'))) else ...list.map((j)=>JobCard(job:j,saved:true,onTap:()=>onOpen(j),onSave:()=>onSave(j)))];}}

class JobDetails extends StatelessWidget {final Job job;final bool saved;final VoidCallback onSave;const JobDetails({super.key,required this.job,required this.saved,required this.onSave});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('চাকরির বিস্তারিত'),actions:[IconButton(onPressed:onSave,icon:Icon(saved?Icons.bookmark:Icons.bookmark_border))]),body:ListView(padding:const EdgeInsets.all(18),children:[Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:const Color(0xFF1457D9),borderRadius:BorderRadius.circular(22)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.factory,color:Colors.white,size:40),const SizedBox(height:12),Text(job.title,style:const TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text(job.company,style:const TextStyle(color:Colors.white70,fontSize:15)),const SizedBox(height:14),Text(job.salary,style:const TextStyle(color:Colors.white,fontSize:17,fontWeight:FontWeight.bold))])),const SizedBox(height:18),_info(Icons.location_on,'লোকেশন',job.location),_info(Icons.work_outline,'অভিজ্ঞতা',job.experience),_info(Icons.school_outlined,'যোগ্যতা',job.education),_info(Icons.people_outline,'প্রার্থী',job.gender),_info(Icons.calendar_today_outlined,'শেষ তারিখ',job.deadline),const SizedBox(height:12),const Text('কাজের বিবরণ',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(job.description,style:const TextStyle(height:1.6)),const SizedBox(height:24),SizedBox(height:52,child:FilledButton.icon(onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('Apply Now'),content:Text('এই ডেমো অ্যাপে ${job.company}-এর ${job.title} পদের জন্য আবেদন প্রক্রিয়া দেখানো হচ্ছে। প্রোডাকশনে এখানে ফোন/WhatsApp/ফর্ম সংযুক্ত করা হবে।'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('ঠিক আছে'))])),icon:const Icon(Icons.send),label:const Text('Apply Now',style:TextStyle(fontSize:16,fontWeight:FontWeight.bold))))]));Widget _info(IconData i,String a,String b)=>ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(backgroundColor:const Color(0xFFEAF2FF),child:Icon(i,color:const Color(0xFF1457D9))),title:Text(a,style:TextStyle(color:Colors.grey.shade600,fontSize:12)),subtitle:Text(b,style:const TextStyle(fontWeight:FontWeight.w700)));}

class Notifications extends StatelessWidget {const Notifications({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Notifications')),body:ListView(children:const[ ListTile(leading:CircleAvatar(child:Icon(Icons.work_outline)),title:Text('নতুন চাকরি এসেছে'),subtitle:Text('গাজীপুরে Sewing Machine Operator নিয়োগ চলছে।')),ListTile(leading:CircleAvatar(child:Icon(Icons.verified_outlined)),title:Text('Verified Job'),subtitle:Text('একটি নতুন Verified চাকরি যোগ হয়েছে।')) ]));}}
class ProfilePage extends StatelessWidget {const ProfilePage({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:[const CircleAvatar(radius:42,child:Icon(Icons.person,size:45)),const SizedBox(height:12),const Center(child:Text('Job Seeker',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900))),const SizedBox(height:24),_tile(Icons.person_outline,'আমার প্রোফাইল'),_tile(Icons.notifications_none,'নোটিফিকেশন সেটিংস'),_tile(Icons.factory_outlined,'Employer / কোম্পানি'),_tile(Icons.admin_panel_settings_outlined,'Admin Dashboard'),_tile(Icons.help_outline,'সহায়তা')]);Widget _tile(IconData i,String t)=>Card(elevation:0,child:ListTile(leading:Icon(i,color:const Color(0xFF1457D9)),title:Text(t),trailing:const Icon(Icons.chevron_right)));}
