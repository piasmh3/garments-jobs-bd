import 'package:flutter/material.dart';
import '../models/job.dart';

class JobCard extends StatelessWidget {
  final Job job;
  final bool saved;
  final VoidCallback onTap;
  final VoidCallback onSave;
  const JobCard({super.key, required this.job, required this.saved, required this.onTap, required this.onSave});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: Colors.grey.shade200)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18), onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFFEAF2FF), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.factory_outlined, color: Color(0xFF1457D9))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(job.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4), Text(job.company, style: TextStyle(color: Colors.grey.shade700)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 6, children: [
                _pill(Icons.location_on_outlined, job.location), _pill(Icons.payments_outlined, job.salary),
              ]),
            ])),
            IconButton(onPressed: onSave, icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border, color: saved ? const Color(0xFF1457D9) : Colors.grey.shade600)),
          ]),
        ),
      ),
    );
  }

  Widget _pill(IconData icon, String text) => Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: const Color(0xFFF5F7FA), borderRadius: BorderRadius.circular(8)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 14, color: const Color(0xFF1457D9)), const SizedBox(width: 4), Text(text, style: const TextStyle(fontSize: 11))]));
}
