class Job {
  final String id;
  final String company;
  final String title;
  final String location;
  final String salary;
  final String experience;
  final String education;
  final String gender;
  final String type;
  final bool featured;
  final String deadline;
  final String description;

  const Job({
    required this.id,
    required this.company,
    required this.title,
    required this.location,
    required this.salary,
    required this.experience,
    required this.education,
    required this.gender,
    required this.type,
    required this.featured,
    required this.deadline,
    required this.description,
  });
}
