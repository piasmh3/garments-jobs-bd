# Garments Jobs BD

A Flutter starter app for a Bangladesh garments-job marketplace.

## Included
- Home / latest & featured jobs
- Search and filters
- Job details and Apply action
- Saved jobs
- Notifications
- Profile
- Employer post-job form
- Admin dashboard mockup
- Bengali-first UI
- No external API required for the demo; jobs are local mock data

## Run
1. Install Flutter 3.22+.
2. Run `flutter pub get`.
3. Run `flutter run`.

## Production next steps
Connect authentication, a backend/database, image upload, push notifications, employer verification, moderation, and real job feeds. Never scrape or republish third-party job data without permission.
